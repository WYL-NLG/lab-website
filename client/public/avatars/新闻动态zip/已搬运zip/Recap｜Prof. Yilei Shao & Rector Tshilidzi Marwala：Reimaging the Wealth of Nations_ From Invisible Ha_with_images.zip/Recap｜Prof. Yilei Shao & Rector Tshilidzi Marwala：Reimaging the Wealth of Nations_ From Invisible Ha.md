![Recap｜Prof. Yilei Shao & Rector Tshilidzi Marwala：Reimaging the Wealth of Nations: From Invisible Hand to Digital Hand](images/cover.jpeg)

# Recap｜Prof. Yilei Shao & Rector Tshilidzi Marwala：Reimaging the Wealth of Nations: From Invisible Hand to Digital Hand

> **作者**: SAIFS
> **发布日期**: 2026年6月10日 19:50
> **来源**: [原文链接](https://mp.weixin.qq.com/s/w-NNbPIZGCB9eujFTSqU7w)

---

![文章图片](images/image1.png)

  

  

  

     2026年6月5日，我们的院长邵艺磊教授与联合国大学（UNU）校长齐利齐·马尔瓦拉教授在东京联合国大学总部举行了一场高层对话，主题为“重新想象国富：从无形之手到数字之手”。与会者包括联合国大学的工作人员、大学生以及相关行业的专业人士。

  

![文章图片](images/image2.jpeg)

SAIFS院长邵艺磊教授与联合国大学校长齐利齐·马尔瓦拉教授合影

     

    对话聚焦于基于硅基经济学的理论框架、全球智能治理机制以及青年发展，深入描绘了人工智能时代的新经济格局和新兴挑战。对话以邵艺磊教授提出的核心理念——基于硅的经济学与智能国内生产（IDP）——开场，探讨了衡量IDP的挑战，并探讨硅指数如何衡量国家的智能能力并为政策制定者提供信息。

  

![文章图片](images/image3.jpeg)

SAIFS院长邵艺磊教授与联合国大学校长齐利齐·马尔瓦拉教授的对话

  

    随后，讨论对比了古典经济学中“看不见的手”与新时代“数字之手”之间的本质区别，并进一步探讨了情报生产和信息消费国家的战略定位。两位发言人还就拟议中的人工智能-欧佩克的运作逻辑和价值以及联合国作为其平台的角色进行了交流，解读了各国开采权相对于情报的实际意义，并探讨了人机协作深度的量化方式。

  

![文章图片](images/image4.jpeg)

Prof. Tshilidzi Marwala, Rector of the United Nations University and Under-Secretary-General of the United Nations

  

    In addition, drawing on the experience of late industrializers in the carbon economy, they assessed the prospects of Global South countries in the silicon economy, before closing with advice for young people on their careers and choices in an uncertain future. Grounded in cutting-edge theory and real-world challenges, the conversation offered profound insights and valuable reference for the global response to the silicon-economy transformation and the improvement of AI governance.

  

![文章图片](images/image5.jpeg)

Prof. Yilei Shao, Dean of the Shanghai AI-Finance School, East China Normal University

  

    Following the on-stage conversation, audience members engaged actively with Prof. Yilei Shao and Rector Tshilidzi Marwala, raising further questions on AI's impact on today's job market, its differing effects across industries, and the evolution of future economic structures. The event concluded in a lively atmosphere with an enthusiastic response.